package com.example.redisdemo.dao;

import com.example.redisdemo.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

import java.util.List;

@Mapper
@Component
public interface UserDao {

    List<User> queryAll();

    User findUserById(int id);

    int updateUser(User user);

    int deleteUserById(int id);

}