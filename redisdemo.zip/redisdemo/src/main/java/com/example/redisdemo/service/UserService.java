package com.example.redisdemo.service;

import com.example.redisdemo.pojo.User;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface UserService {


    List<User> queryAll();

    User findUserById(int id);

    int updateUser(User user);

    int deleteUserById(int id);
}